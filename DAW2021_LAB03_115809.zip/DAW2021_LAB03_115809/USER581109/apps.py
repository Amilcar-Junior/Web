from django.apps import AppConfig


class USER581109Config(AppConfig):
    name = 'USER581109'
