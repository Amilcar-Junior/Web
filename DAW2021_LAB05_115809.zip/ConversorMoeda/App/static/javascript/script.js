// API: https://www.exchangerate-api.com/docs/overview

const m1 = document.getElementById("moeda_1")
const m2 = document.getElementById("moeda_2");
const valor1 = document.getElementById("valor-1");
const valor2 = document.getElementById("valor-2");
const converter = document.getElementById("converter");
const theRate = document.getElementById("rate");

function conversor() {
  const moeda1 = m1.value;
  const moeda2 = m2.value;  
  fetch(`https://v6.exchangerate-api.com/v6/9b79053709bac1f608449ac1/latest/${moeda1}`)
        // carrega de forma assíncrona o conteúdo do url
        // retorna uma promessa que resolve quando res é carregado
    .then((res) => res.json()) // chama esta função quando res é carregado
        // retorna uma promessa com o resultado da função acima
    .then((data) => {
      // Atualizando os dados
      const rate = data.conversion_rates[moeda2];
      theRate.innerText = `1 ${moeda1} = ${rate} ${moeda2}`;
      valor2.value = (valor1.value * rate).toFixed(2);
    });
}

converter.addEventListener("click", () => {
  conversor();
});
